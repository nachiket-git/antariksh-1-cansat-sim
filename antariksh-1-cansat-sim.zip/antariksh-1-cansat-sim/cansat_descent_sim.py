"""
CanSat descent simulation — Team Antariksh-1, NAT-004
SEVA FIRST Innovation Challenge 2026, Screen-2 supporting evidence (Point 4).

Models the vertical descent of a 0.6 kg CanSat under a parachute released at 500 m,
and the horizontal landing drift for a range of wind speeds.

Run:  python cansat_descent_sim.py
Outputs: console summary + descent_sim.png
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --- parameters (edit to match your build) ---
m = 0.6          # payload mass, kg (within the <= 700 g limit)
g = 9.81         # gravity, m/s^2
rho = 1.225      # air density, kg/m^3
Cd = 0.8         # parachute drag coefficient
A = 0.334        # parachute canopy area, m^2  (=> ~65 cm diameter)
H0 = 500.0       # release altitude, m
dt = 0.001       # integration step, s

k = 0.5 * rho * Cd * A
v_terminal = np.sqrt(2 * m * g / (rho * Cd * A))

# --- vertical descent ---
t, h, v = 0.0, H0, 0.0
ts, hs, vs = [t], [h], [v]
while h > 0 and t < 300:
    a = g - k * v * v / m          # net acceleration (down positive)
    v += a * dt
    h -= v * dt
    t += dt
    ts.append(t); hs.append(h); vs.append(v)
ts, hs, vs = np.array(ts), np.array(hs), np.array(vs)
descent_time = ts[-1]


def drift(w):
    """Horizontal drift for a steady wind w, same drag model."""
    vx, x, tt = 0.0, 0.0, 0.0
    while tt < descent_time:
        dvx = k * (w - vx) * abs(w - vx) / m
        vx += dvx * dt
        x += vx * dt
        tt += dt
    return x


winds = np.array([0, 1, 2, 3, 4, 5])
drifts = np.array([drift(w) for w in winds])

print(f"Terminal descent velocity : {v_terminal:.2f} m/s  (target 5-8 m/s)")
print(f"Descent time from {H0:.0f} m   : {descent_time:.1f} s")
for w, d in zip(winds, drifts):
    print(f"  drift at {w} m/s wind     : {d:.0f} m")

# --- figure ---
fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
ax[0].plot(ts, hs, color="#B01818", lw=2)
ax[0].set_xlabel("Time (s)"); ax[0].set_ylabel("Altitude (m)", color="#B01818")
ax[0].tick_params(axis="y", labelcolor="#B01818")
ax2 = ax[0].twinx()
ax2.plot(ts, vs, color="#1A1A1A", lw=1.4, ls="--")
ax2.axhline(5, color="#888", lw=0.8, ls=":"); ax2.axhline(8, color="#888", lw=0.8, ls=":")
ax2.set_ylabel("Descent rate (m/s)")
ax[0].set_title("Descent from 500 m (parachute)", fontsize=10); ax[0].grid(alpha=0.25)

ax[1].bar(winds, drifts, color="#B01818", width=0.6)
for w, d in zip(winds, drifts):
    ax[1].text(w, d + 6, f"{d:.0f}", ha="center", fontsize=9)
ax[1].set_xlabel("Wind speed (m/s)"); ax[1].set_ylabel("Horizontal drift (m)")
ax[1].set_title("Landing drift vs wind", fontsize=10); ax[1].grid(alpha=0.25, axis="y")

plt.tight_layout()
plt.savefig("descent_sim.png", dpi=150)
print("Saved descent_sim.png")
